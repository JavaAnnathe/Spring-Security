package com.annathe.training.empsystem;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.annathe.training.empsystem.controller.EmployeeController;

@SpringBootTest
@AutoConfigureMockMvc
class EmpsystemApplicationTests {
	
	@Autowired
	private EmployeeController employeeController;

	@Autowired
	private MockMvc mvc;

	@Test
	void contextLoads() {
	}
	
	@Test 
	  public void testGetEmployee() throws Exception {
	  
	  ResultActions actions = mvc.perform(get("/employees/dummy"));
	  actions.andExpect(status().isOk());
	  actions.andExpect(jsonPath("$.name").exists());
	  actions.andExpect(jsonPath("$.name").value("Murugan"));
	  
	  }

}
